from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from datetime import datetime

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('vendedor.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('vendedor.html')

@app.route('/pedidos', methods=['GET'])
def pedidos():
    conn = get_db_connection()
    pedidos = conn.execute('SELECT * FROM pedidos').fetchall()
    conn.close()
    return render_template('vendedor.html', pedidos=pedidos)

@app.route('/finalizar_pedido/<int:id>', methods=['POST'])
def finalizar_pedido(id):
    conn = get_db_connection()
    conn.execute('UPDATE pedidos SET status = "Finalizado" WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('pedidos'))

@app.route('/cancelar_pedido/<int:id>', methods=['POST'])
def cancelar_pedido(id):
    conn = get_db_connection()
    conn.execute('UPDATE pedidos SET status = "Cancelado" WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('pedidos'))

@app.route('/adicionar_pedido', methods=['POST'])
def adicionar_pedido():
    cliente = request.form['cliente']
    valor = request.form['valor']
    data = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = get_db_connection()
    conn.execute('INSERT INTO pedidos (cliente, valor, status, data) VALUES (?, ?, "Pendente", ?)',
                 (cliente, valor, data))
    conn.commit()
    conn.close()
    return redirect(url_for('pedidos'))

@app.route('/relatorio')
def relatorio():
    conn = get_db_connection()
    finalizados = conn.execute('SELECT * FROM pedidos WHERE status = "Finalizado"').fetchall()
    cancelados = conn.execute('SELECT * FROM pedidos WHERE status = "Cancelado"').fetchall()
    ganho_dia = conn.execute('SELECT SUM(valor) FROM pedidos WHERE status = "Finalizado" AND date(data) = date("now")').fetchone()[0] or 0
    ganho_mes = conn.execute('SELECT SUM(valor) FROM pedidos WHERE status = "Finalizado" AND strftime("%m", data) = strftime("%m", "now")').fetchone()[0] or 0
    conn.close()
    return render_template('vendedor.html', finalizados=finalizados, cancelados=cancelados, ganho_dia=ganho_dia, ganho_mes=ganho_mes)

if __name__ == '__main__':
    app.run(debug=True)