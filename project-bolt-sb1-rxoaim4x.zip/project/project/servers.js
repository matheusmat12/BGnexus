const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

let pedidos = []; // Aqui vamos guardar os pedidos

// Rota para receber pedidos do cliente
app.post('/pedidos', (req, res) => {
  const novoPedido = req.body;
  pedidos.push(novoPedido);
  console.log('Novo pedido recebido:', novoPedido);
  res.send('Pedido recebido com sucesso!');
});

// Rota para o vendedor ver os pedidos
app.get('/pedidos', (req, res) => {
  res.json(pedidos);
});

// Rota para atualizar o status do pedido
app.put('/pedidos/:id', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const pedido = pedidos.find(p => p.id === Number(id));
  if (pedido) {
    pedido.status = status;
    console.log(`Status do pedido ${id} atualizado para: ${status}`);
    res.send('Status atualizado com sucesso!');
  } else {
    res.status(404).send('Pedido não encontrado.');
  }
});

// Inicia o servidor
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Servidor do vendedor rodando na porta ${PORT}`);
});