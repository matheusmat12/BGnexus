import React, { useState, useEffect } from 'react';
import { MenuItem, CartItem, OrderType } from './types';
import MenuCarousel from './components/MenuCarousel';
import Cart from './components/Cart';
import CheckoutForm from './components/CheckoutForm';
import ContactInfo from './components/ContactInfo';
import notificationSound from './assets/notification.mp3'; // Certifique-se de que o arquivo existe
import Calendar from 'react-calendar'; // Importação do Calendar
import 'react-calendar/dist/Calendar.css'; // Importação dos estilos do Calendar
import { FaShoppingCart } from 'react-icons/fa'; // Importando ícone de carrinho

// Definição dos tipos
type OrderStatus = 'ACTIVE' | 'COMPLETED' | 'CANCELLED';

type Order = {
  id: number;
  items: { name: string; quantity: number }[];
  total: number;
  address: string;
  paymentMethod: string;
  status: OrderStatus;
  createdAt: Date; // Data e hora do pedido
  orderType: OrderType; // 'DELIVERY' ou 'PICKUP'
};

// Itens do menu
const foodItems: MenuItem[] = [
  {
    id: 1,
    name: 'Classic Burger',
    price: 12.99,
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&h=400&fit=crop'
  },
  {
    id: 2,
    name: 'Veggie Burger',
    price: 11.99,
    image: 'https://images.unsplash.com/photo-1520072959219-c595dc870360?w=500&h=400&fit=crop'
  },
  {
    id: 3,
    name: 'Chicken Sandwich',
    price: 10.99,
    image: 'https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=500&h=400&fit=crop'
  }
];

const drinkItems: MenuItem[] = [
  {
    id: 4,
    name: 'Cola',
    price: 2.99,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&h=400&fit=crop'
  },
  {
    id: 5,
    name: 'Lemonade',
    price: 3.99,
    image: 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=500&h=400&fit=crop'
  },
  {
    id: 6,
    name: 'Iced Tea',
    price: 2.99,
    image: 'https://images.unsplash.com/photo-1499638673689-79a0b5115d87?w=500&h=400&fit=crop'
  }
];

// Funções para salvar e carregar pedidos
const saveOrdersToLocalStorage = (orders: Order[]) => {
  localStorage.setItem('orders', JSON.stringify(orders));
};

const loadOrdersFromLocalStorage = (): Order[] => {
  const savedOrders = localStorage.getItem('orders');
  return savedOrders ? JSON.parse(savedOrders) : [];
};

// Componente Error Boundary
class ErrorBoundary extends React.Component {
  state = { hasError: false };

  static getDerivedStateFromError(error: Error) {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("Erro capturado por Error Boundary:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return <h1 className="text-red-500">Algo deu errado.</h1>;
    }

    return this.props.children; 
  }
}

// Componente de Login
const LoginPage = ({ onLogin }: { onLogin: (username: string, password: string) => void }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(username, password);
  };

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <div className="bg-black p-8 rounded-lg shadow-lg w-96">
        <h2 className="text-2xl font-bold mb-6 text-white">Vendedor Login</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-white mb-2">Usuário</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-3 py-2 bg-gray-800 text-white rounded"
              required
            />
          </div>
          <div className="mb-6">
            <label className="block text-white mb-2">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 bg-gray-800 text-white rounded"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
          >
            Entrar
          </button>
        </form>
      </div>
    </div>
  );
};

// Componente de Carrinho Flutuante
const FloatingCart = ({ items, onUpdateQuantity, onRemove, onToggleDetails }) => {
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="fixed bottom-4 left-4 flex items-center justify-center">
      <div className="relative w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center shadow-lg cursor-pointer" onClick={onToggleDetails}>
        <FaShoppingCart className="text-white text-3xl" />
        {totalItems > 0 && (
          <span className="absolute top-0 right-0 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
            {totalItems}
          </span>
        )}
      </div>
    </div>
  );
};

// Componente de Detalhes do Carrinho
const CartDetails = ({ items, onUpdateQuantity, onRemove, onPlaceOrder }) => {
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="fixed bottom-20 left-4 bg-black p-4 rounded-lg shadow-lg w-64">
      <h3 className="text-lg font-semibold text-white">Detalhes do Carrinho</h3>
      <ul className="mt-2">
        {items.length === 0 ? (
          <li className="text-gray-400">Carrinho vazio</li>
        ) : (
          items.map((item, index) => (
            <li key={index} className="text-gray-300 flex justify-between">
              {item.name} x {item.quantity}
              <button onClick={() => onRemove(item.id)} className="text-red-500">Remover</button>
            </li>
          ))
        )}
      </ul>
      <p className="mt-2 text-white">Total: R$ {total.toFixed(2)}</p>
      <button
        onClick={onPlaceOrder}
        className="mt-2 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 w-full"
      >
        Finalizar Pedido
      </button>
    </div>
  );
};

// Componente de Pedidos
const OrdersPage = ({ orders, onBack, onCancelOrder, onCompleteOrder }: { 
  orders: Order[], 
  onBack: () => void,
  onCancelOrder: (orderId: number) => void,
  onCompleteOrder: (orderId: number) => void
}) => {
  const [minimizedActive, setMinimizedActive] = useState(false);
  const [minimizedCompleted, setMinimizedCompleted] = useState(false);
  const [minimizedCancelled, setMinimizedCancelled] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showCalendar, setShowCalendar] = useState(false); // Estado para mostrar/ocultar o calendário

  const filteredOrders = selectedDate
    ? orders.filter(order => new Date(order.createdAt).toDateString() === selectedDate.toDateString())
    : orders;

  const totalEarnedToday = orders
    .filter(order => order.status === 'COMPLETED' && new Date(order.createdAt).toDateString() === new Date().toDateString())
    .reduce((sum, order) => sum + order.total, 0);

  const handlePlaceOrder = async (address: string, paymentMethod: string, customerPhone?: string) => {
    const newOrder = {
      id: orders.length + 1,
      items: cart.map(item => ({ name: item.name, quantity: item.quantity })),
      total: cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
      address,
      paymentMethod,
      status: 'ACTIVE',
      createdAt: new Date(), // Data e hora do pedido
      orderType,
      customerPhone,
    };

    try {
      // Envia o pedido para o servidor do vendedor
      const response = await fetch('http://localhost:5173/pedidos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrder),
      });

      const responseData = await response.json(); // Adicionando para ver a resposta
      console.log(responseData); // Log da resposta do servidor

      if (response.ok) {
        setOrders([...orders, newOrder]);
        setCart([]);
        setShowCheckout(false);
        setOrderCompleted(true);
      } else {
        alert('Erro ao enviar o pedido. Tente novamente.');
      }
    } catch (error) {
      console.error('Erro:', error);
      alert('Erro ao enviar o pedido. Tente novamente.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 p-8">
      <h2 className="text-2xl font-bold mb-6 text-white">Pedidos Recebidos</h2>

      <div className="text-white mb-4">
        <h3 className="text-xl font-semibold">Total Ganhos Hoje: R$ {totalEarnedToday.toFixed(2)}</h3>
      </div>

      {/* Seção de Pedidos em Andamento */}
      <h3 className="text-xl font-semibold text-white mb-4 flex justify-between">
        Pedidos em Andamento
        <button onClick={() => setMinimizedActive(!minimizedActive)} className="text-gray-400">
          {minimizedActive ? 'Expandir' : 'Minimizar'}
        </button>
      </h3>
      {!minimizedActive && filteredOrders.filter(order => order.status === 'ACTIVE').map(order => (
        <div key={order.id} className="bg-black p-6 rounded-lg shadow-lg mb-4">
          <h3 className="text-xl font-semibold text-white flex justify-between">
            <span>Pedido #{order.id}</span>
          </h3>
          <ul className="mt-2">
            {order.items.map((item, index) => (
              <li key={index} className="text-gray-300">
                {item.name} x {item.quantity}
              </li>
            ))}
          </ul>
          <p className="mt-2 text-white">Total: R$ {order.total.toFixed(2)}</p>
          <p className="text-gray-400">Endereço: {order.address}</p>
          <p className="text-gray-400">Pagamento: {order.paymentMethod}</p>
          <p className="text-gray-400">Tipo: {order.orderType === 'PICKUP' ? 'Retirada' : 'Entrega'}</p>
          <p className="text-gray-400">Data e Hora: {new Date(order.createdAt).toLocaleString()}</p>
          <div className="mt-4 space-x-2">
            <button
              onClick={() => onCompleteOrder(order.id)}
              className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
            >
              Finalizar Pedido
            </button>
            <button
              onClick={() => onCancelOrder(order.id)}
              className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
            >
              Cancelar Pedido
            </button>
          </div>
        </div>
      ))}

      {/* Seção de Pedidos Concluídos */}
      <h3 className="text-xl font-semibold text-white mb-4 flex justify-between">
        Pedidos Concluídos
        <button onClick={() => setMinimizedCompleted(!minimizedCompleted)} className="text-gray-400">
          {minimizedCompleted ? 'Expandir' : 'Minimizar'}
        </button>
      </h3>
      {!minimizedCompleted && filteredOrders.filter(order => order.status === 'COMPLETED').map(order => (
        <div key={order.id} className="bg-black p-6 rounded-lg shadow-lg mb-4">
          <h3 className="text-xl font-semibold text-white flex justify-between">
            <span>Pedido #{order.id}</span>
          </h3>
          <ul className="mt-2">
            {order.items.map((item, index) => (
              <li key={index} className="text-gray-300">
                {item.name} x {item.quantity}
              </li>
            ))}
          </ul>
          <p className="mt-2 text-white">Total: R$ {order.total.toFixed(2)}</p>
          <p className="text-gray-400">Endereço: {order.address}</p>
          <p className="text-gray-400">Pagamento: {order.paymentMethod}</p>
          <p className="text-gray-400">Tipo: {order.orderType === 'PICKUP' ? 'Retirada' : 'Entrega'}</p>
          <p className="text-gray-400">Data e Hora: {new Date(order.createdAt).toLocaleString()}</p>
        </div>
      ))}

      {/* Seção de Pedidos Cancelados */}
      <h3 className="text-xl font-semibold text-white mb-4 flex justify-between">
        Pedidos Cancelados
        <button onClick={() => setMinimizedCancelled(!minimizedCancelled)} className="text-gray-400">
          {minimizedCancelled ? 'Expandir' : 'Minimizar'}
        </button>
      </h3>
      {!minimizedCancelled && filteredOrders.filter(order => order.status === 'CANCELLED').map(order => (
        <div key={order.id} className="bg-black p-6 rounded-lg shadow-lg mb-4">
          <h3 className="text-xl font-semibold text-white flex justify-between">
            <span>Pedido #{order.id}</span>
          </h3>
          <ul className="mt-2">
            {order.items.map((item, index) => (
              <li key={index} className="text-gray-300">
                {item.name} x {item.quantity}
              </li>
            ))}
          </ul>
          <p className="mt-2 text-white">Total: R$ {order.total.toFixed(2)}</p>
          <p className="text-gray-400">Endereço: {order.address}</p>
          <p className="text-gray-400">Pagamento: {order.paymentMethod}</p>
          <p className="text-gray-400">Tipo: {order.orderType === 'PICKUP' ? 'Retirada' : 'Entrega'}</p>
          <p className="text-gray-400">Data e Hora: {new Date(order.createdAt).toLocaleString()}</p>
        </div>
      ))}

      <button
        onClick={onBack}
        className="fixed bottom-4 right-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Voltar
      </button>

      {/* Botão do Calendário */}
      <button
        onClick={() => setShowCalendar(prev => !prev)}
        className="fixed bottom-32 right-4 bg-green-600 text-white rounded-full p-3 hover:bg-blue-700"
      >
        <span className="material-icons">📅</span>
      </button>

      {showCalendar && (
        <div className="absolute bottom-24 right-4">
          <Calendar onChange={setSelectedDate} value={selectedDate} />
        </div>
      )}
    </div>
  );
}

function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCheckout, setShowCheckout] = useState(false);
  const [orderType, setOrderType] = useState<OrderType>('PICKUP');
  const [orders, setOrders] = useState<Order[]>(loadOrdersFromLocalStorage());
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [orderCompleted, setOrderCompleted] = useState(false);
  const [showCartDetails, setShowCartDetails] = useState(false); // Estado para controlar a visibilidade do carrinho detalhado

  // Efeito para salvar pedidos no localStorage
  useEffect(() => {
    saveOrdersToLocalStorage(orders);
  }, [orders]);

  // Efeito para tocar som de notificação ao receber um novo pedido
  useEffect(() => {
    if (orders.length > 0) {
      const audio = new Audio(notificationSound);
      audio.play();
    }
  }, [orders]);

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => 
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const removeFromCart = (itemId: number) => {
    setCart(prev => prev.filter(item => item.id !== itemId));
  };

  const updateQuantity = (itemId: number, quantity: number) => {
    if (quantity < 1) {
      removeFromCart(itemId);
      return;
    }
    setCart(prev => 
      prev.map(item => 
        item.id === itemId ? { ...item, quantity } : item
      )
    );
  };

  const handlePlaceOrder = async (address: string, paymentMethod: string, customerPhone?: string) => {
    const newOrder = {
      id: orders.length + 1,
      items: cart.map(item => ({ name: item.name, quantity: item.quantity })),
      total: cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
      address,
      paymentMethod,
      status: 'ACTIVE',
      createdAt: new Date(), // Data e hora do pedido
      orderType,
      customerPhone,
    };

    try {
      // Envia o pedido para o servidor do vendedor
      const response = await fetch('http://localhost:5000/pedidos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrder),
      });

      const responseData = await response.json(); // Adicionando para ver a resposta
      console.log(responseData); // Log da resposta do servidor

      if (response.ok) {
        setOrders([...orders, newOrder]);
        setCart([]);
        setShowCheckout(false);
        setOrderCompleted(true);
      } else {
        alert('Erro ao enviar o pedido. Tente novamente.');
      }
    } catch (error) {
      console.error('Erro:', error);
      alert('Erro ao enviar o pedido. Tente novamente.');
    }
  };

  const handleCancelOrder = (orderId: number) => {
    setOrders(prevOrders =>
      prevOrders.map(order =>
        order.id === orderId ? { ...order, status: 'CANCELLED' } : order
      )
    );
  };

  const handleCompleteOrder = (orderId: number) => {
    setOrders(prevOrders =>
      prevOrders.map(order =>
        order.id === orderId ? { ...order, status: 'COMPLETED' } : order
      )
    );
  };

  const handleLogin = (username: string, password: string) => {
    // Aqui você pode adicionar a lógica de autenticação
    // Por exemplo, verificar se o usuário e a senha estão corretos
    if (username === 'admin' && password === 'admin') {
      setIsLoggedIn(true);
      setShowLogin(false);
    } else {
      alert('Usuário ou senha incorretos');
    }
  };

  return (
    <div className="min-h-screen bg-gray-900">
      {isLoggedIn ? (
        <ErrorBoundary>
          <OrdersPage 
            orders={orders} 
            onBack={() => setIsLoggedIn(false)} 
            onCancelOrder={handleCancelOrder}
            onCompleteOrder={handleCompleteOrder}
          />
        </ErrorBoundary>
      ) : showCheckout ? (
        <CheckoutForm 
          onBack={() => setShowCheckout(false)}
          orderType={orderType}
          setOrderType={setOrderType}
          onPlaceOrder={handlePlaceOrder}
        />
      ) : (
        <>
          <header className="bg-black shadow-lg">
            <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
              <div className="flex items-center">
                <img src="/logo.png" alt="Logo" className="h-12 mr-4" />
                <h1 className="text-3xl font-bold text-white">Delicious Eats</h1>
              </div>
              <button
                onClick={() => setShowLogin(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
              >
                Área do Vendedor
              </button>
            </div>
          </header>

          <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <div>
                  <h2 className="text-2xl font-semibold mb-4 text-white">Food Menu</h2>
                  <MenuCarousel items={foodItems} onSelect={addToCart} itemsPerView={2} />
                </div>
                <div>
                  <h2 className="text-2xl font-semibold mb-4 text-white">Drinks Menu</h2>
                  <MenuCarousel items={drinkItems} onSelect={addToCart} itemsPerView={2} />
                </div>
              </div>

              <div className="lg:col-span-1">
                <Cart 
                  items={cart}
                  onUpdateQuantity={updateQuantity}
                  onRemove={removeFromCart}
                  onPlaceOrder={() => setShowCheckout(true)}
                />
              </div>
            </div>

            <ContactInfo />
          </main>

          {/* Carrinho Flutuante */}
          <FloatingCart 
            items={cart}
            onUpdateQuantity={updateQuantity}
            onRemove={removeFromCart}
            onToggleDetails={() => setShowCartDetails(prev => !prev)} // Adicionando a função para alternar detalhes do carrinho
          />

          {/* Detalhes do Carrinho */}
          {showCartDetails && (
            <CartDetails 
              items={cart}
              onUpdateQuantity={updateQuantity}
              onRemove={removeFromCart}
              onPlaceOrder={handlePlaceOrder}
            />
          )}
        </>
      )}

      {showLogin && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <LoginPage onLogin={handleLogin} />
        </div>
      )}

      {/* Modal de "Pedido Finalizado" */}
      {orderCompleted && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-black p-8 rounded-lg shadow-lg text-center">
            <h2 className="text-2xl font-bold text-white mb-4">Pedido Finalizado!</h2>
            <div className="space-x-2">
              <button
                onClick={() => setOrderCompleted(false)}
                className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;