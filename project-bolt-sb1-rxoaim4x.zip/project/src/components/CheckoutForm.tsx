import React, { useState } from 'react';
import { MapPin, CreditCard } from 'lucide-react';
import { OrderType } from '../types';

interface CheckoutFormProps {
  onBack: () => void;
  orderType: OrderType;
  setOrderType: (type: OrderType) => void;
  onPlaceOrder: (address: string, paymentMethod: string) => void;
}

const CheckoutForm: React.FC<CheckoutFormProps> = ({ 
  onBack, 
  orderType, 
  setOrderType, 
  onPlaceOrder 
}) => {
  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onPlaceOrder(address, paymentMethod);
  };

  return (
    <div className="bg-black p-6 rounded-lg shadow-lg">
      <h2 className="text-xl font-semibold text-white mb-4">Finalizar Pedido</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-white mb-2">Tipo de Pedido</label>
          <select
            value={orderType}
            onChange={(e) => setOrderType(e.target.value as OrderType)}
            className="w-full px-3 py-2 bg-gray-800 text-white rounded"
          >
            <option value="PICKUP">Retirada</option>
            <option value="DELIVERY">Entrega</option>
          </select>
        </div>

        {orderType === 'DELIVERY' && (
          <div className="mb-4">
            <label className="block text-white mb-2">Endereço de Entrega</label>
            <div className="flex items-center gap-2 bg-gray-800 p-2 rounded">
              <MapPin className="text-gray-400" />
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-gray-800 text-white outline-none"
                placeholder="Digite o endereço"
                required={orderType === 'DELIVERY'}
              />
            </div>
          </div>
        )}

        <div className="mb-4">
          <label className="block text-white mb-2">Método de Pagamento</label>
          <div className="flex items-center gap-2 bg-gray-800 p-2 rounded">
            <CreditCard className="text-gray-400" />
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
              className="w-full bg-gray-800 text-white outline-none"
              required
            >
              <option value="">Selecione</option>
              <option value="CARD">Cartão de Crédito</option>
              <option value="CASH">Dinheiro</option>
              <option value="PIX">PIX</option>
            </select>
          </div>
        </div>

        <div className="flex justify-between mt-6">
          <button
            type="button"
            onClick={onBack}
            className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700"
          >
            Voltar
          </button>
          <button
            type="submit"
            className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
          >
            Finalizar Pedido
          </button>
        </div>
      </form>
    </div>
  );
};

export default CheckoutForm;