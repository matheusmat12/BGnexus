import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { CartItem } from '../types';

interface CartProps {
  items: CartItem[];
  onUpdateQuantity: (itemId: number, quantity: number) => void;
  onRemove: (itemId: number) => void;
  onPlaceOrder: () => void;
}

const Cart: React.FC<CartProps> = ({ items, onUpdateQuantity, onRemove, onPlaceOrder }) => {
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="bg-black p-6 rounded-lg shadow-lg">
      <div className="flex items-center gap-2 mb-4">
        <ShoppingCart className="text-white" />
        <h2 className="text-xl font-semibold text-white">Carrinho</h2>
      </div>

      {items.length === 0 ? (
        <p className="text-gray-400">Carrinho vazio</p>
      ) : (
        <>
          <div className="space-y-4">
            {items.map((item) => (
              <div key={item.id} className="flex justify-between items-center">
                <div>
                  <h3 className="text-white">{item.name}</h3>
                  <p className="text-gray-400">R$ {item.price.toFixed(2)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => onUpdateQuantity(item.id, parseInt(e.target.value))}
                    className="w-16 px-2 py-1 bg-gray-800 text-white rounded"
                    min="1"
                  />
                  <button
                    onClick={() => onRemove(item.id)}
                    className="text-red-500 hover:text-red-600"
                  >
                    Remover
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 border-t border-gray-800 pt-4">
            <div className="flex justify-between mb-4">
              <span className="text-white">Total:</span>
              <span className="text-white">R$ {total.toFixed(2)}</span>
            </div>
            <button
              onClick={onPlaceOrder}
              className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700"
            >
              Finalizar Pedido
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default Cart;