import React from 'react';
import { Phone, Instagram, MapPin } from 'lucide-react';

const ContactInfo: React.FC = () => {
  return (
    <div className="mt-16 flex justify-center">
      <div className="flex gap-8 items-center text-sm">
        <a
          href="tel:+5519996887049"
          className="text-blue-400 hover:text-blue-300 flex items-center gap-2"
        >
          <Phone className="w-4 h-4" />
          (19) 99688-7049
        </a>
        
        <a 
          href="https://instagram.com/yourrestaurant" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-blue-400 hover:text-blue-300 flex items-center gap-2"
        >
          <Instagram className="w-4 h-4" />
          @yourrestaurant
        </a>
        
        <a
          href="https://maps.google.com/?q=your+address"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-400 hover:text-blue-300 flex items-center gap-2"
        >
          <MapPin className="w-4 h-4" />
          Visit Us
        </a>
      </div>
    </div>
  );
};

export default ContactInfo;