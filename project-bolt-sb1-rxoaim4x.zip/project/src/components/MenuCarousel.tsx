import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { MenuItem } from '../types';

interface MenuCarouselProps {
  items: MenuItem[];
  onSelect: (item: MenuItem) => void;
  itemsPerView: number;
}

const MenuCarousel: React.FC<MenuCarouselProps> = ({ items, onSelect, itemsPerView }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prev) => Math.min(prev + 1, items.length - itemsPerView));
  };

  const prev = () => {
    setCurrentIndex((prev) => Math.max(prev - 1, 0));
  };

  const canGoNext = currentIndex < items.length - itemsPerView;
  const canGoPrev = currentIndex > 0;

  return (
    <div className="relative bg-navy-900 rounded-lg p-4">
      <div className="overflow-hidden">
        <div 
          className="flex transition-transform duration-300 ease-in-out gap-4"
          style={{ transform: `translateX(-${currentIndex * (100 / itemsPerView)}%)` }}
        >
          {items.map((item) => (
            <div 
              key={item.id} 
              className="flex-shrink-0"
              style={{ width: `${100 / itemsPerView}%` }}
            >
              <div className="bg-black rounded-lg shadow-xl overflow-hidden mx-2">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-40 object-cover"
                />
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-white">{item.name}</h3>
                  <p className="text-blue-400">${item.price.toFixed(2)}</p>
                  <button
                    onClick={() => onSelect(item)}
                    className="mt-2 w-full bg-blue-900 text-white px-4 py-2 rounded-md hover:bg-blue-800 transition-colors"
                  >
                    Adicionar ao Carrinho
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {canGoPrev && (
        <button
          onClick={prev}
          className="absolute left-2 top-1/2 -translate-y-1/2 bg-blue-900 text-white p-1 rounded-full shadow-lg hover:bg-blue-800"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      )}
      
      {canGoNext && (
        <button
          onClick={next}
          className="absolute right-2 top-1/2 -translate-y-1/2 bg-blue-900 text-white p-1 rounded-full shadow-lg hover:bg-blue-800"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      )}
    </div>
  );
};

export default MenuCarousel;