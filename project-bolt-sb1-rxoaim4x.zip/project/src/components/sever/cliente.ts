import React, { useState, useEffect } from 'react';
import { ShoppingCart, MapPin, Phone, Instagram, CreditCard } from 'lucide-react';
import { MenuItem, CartItem, OrderType } from './types';
import MenuCarousel from './components/MenuCarousel';
import Cart from './components/Cart';
import CheckoutForm from './components/CheckoutForm';
import ContactInfo from './components/ContactInfo';
import notificationSound from './assets/notification.mp3'; // Certifique-se de que o arquivo existe

// Definição dos tipos
type OrderStatus = 'ACTIVE' | 'COMPLETED' | 'CANCELLED';

type Order = {
  id: number;
  items: { name: string; quantity: number }[];
  total: number;
  address: string;
  paymentMethod: string;
  status: OrderStatus;
  createdAt: Date;
  orderType: OrderType; // 'DELIVERY' ou 'PICKUP'
};

// Itens do menu
const foodItems: MenuItem[] = [
  {
    id: 1,
    name: 'Classic Burger',
    price: 12.99,
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&h=400&fit=crop'
  },
  {
    id: 2,
    name: 'Veggie Burger',
    price: 11.99,
    image: 'https://images.unsplash.com/photo-1520072959219-c595dc870360?w=500&h=400&fit=crop'
  },
  {
    id: 3,
    name: 'Chicken Sandwich',
    price: 10.99,
    image: 'https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=500&h=400&fit=crop'
  }
];

const drinkItems: MenuItem[] = [
  {
    id: 4,
    name: 'Cola',
    price: 2.99,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&h=400&fit=crop'
  },
  {
    id: 5,
    name: 'Lemonade',
    price: 3.99,
    image: 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=500&h=400&fit=crop'
  },
  {
    id: 6,
    name: 'Iced Tea',
    price: 2.99,
    image: 'https://images.unsplash.com/photo-1499638673689-79a0b5115d87?w=500&h=400&fit=crop'
  }
];

// Funções para salvar e carregar pedidos
const saveOrdersToLocalStorage = (orders: Order[]) => {
  localStorage.setItem('orders', JSON.stringify(orders));
};

const loadOrdersFromLocalStorage = (): Order[] => {
  const savedOrders = localStorage.getItem('orders');
  return savedOrders ? JSON.parse(savedOrders) : [];
};

// Componente de Login
const LoginPage = ({ onLogin }: { onLogin: (username: string, password: string) => void }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(username, password);
  };

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <div className="bg-black p-8 rounded-lg shadow-lg w-96">
        <h2 className="text-2xl font-bold mb-6 text-white">Vendedor Login</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-white mb-2">Usuário</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-3 py-2 bg-gray-800 text-white rounded"
              required
            />
          </div>
          <div className="mb-6">
            <label className="block text-white mb-2">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-3 py-2 bg-gray-800 text-white rounded"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
          >
            Entrar
          </button>
        </form>
      </div>
    </div>
  );
};

// Componente de Pedidos
const OrdersPage = ({ orders, onBack, onCancelOrder, onCompleteOrder }: { 
  orders: Order[], 
  onBack: () => void,
  onCancelOrder: (orderId: number) => void,
  onCompleteOrder: (orderId: number) => void
}) => {
  const activeOrders = orders.filter(order => order.status === 'ACTIVE');
  const completedOrders = orders.filter(order => order.status === 'COMPLETED');
  const cancelledOrders = orders.filter(order => order.status === 'CANCELLED');

  const totalEarnedToday = completedOrders
    .filter(order => new Date(order.createdAt).toDateString() === new Date().toDateString())
    .reduce((sum, order) => sum + order.total, 0);

  const totalEarnedThisMonth = completedOrders
    .filter(order => new Date(order.createdAt).getMonth() === new Date().getMonth())
    .reduce((sum, order) => sum + order.total, 0);

  return (

    <div className="min-h-screen bg-gray-900 p-8">
      <h2 className="text-2xl font-bold mb-6 text-white">Pedidos Recebidos</h2>
      
      <div className="mb-8">
        <h3 className="text-xl font-semibold text-white">Ganhos</h3>
        <p className="text-gray-300">Hoje: R$ {totalEarnedToday.toFixed(2)}</p>
        <p className="text-gray-300">Este Mês: R$ {totalEarnedThisMonth.toFixed(2)}</p>
      </div>

      {['ACTIVE', 'COMPLETED', 'CANCELLED'].map(status => (
        <div key={status}>
          <h3 className="text-xl font-semibold text-white mb-4">
            {status === 'ACTIVE' ? 'Pedidos Ativos' : status === 'COMPLETED' ? 'Pedidos Finalizados' : 'Pedidos Cancelados'}
          </h3>
          <div className="space-y-4 mb-8">
            {orders.filter(order => order.status === status).map(order => (
              <div key={order.id} className="bg-black p-6 rounded-lg shadow-lg">
                <h3 className="text-xl font-semibold text-white">Pedido #{order.id}</h3>
                <ul className="mt-2">
                  {order.items.map((item, index) => (
                    <li key={index} className="text-gray-300">
                      {item.name} x {item.quantity}
                    </li>
                  ))}
                </ul>
                <p className="mt-2 text-white">Total: R$ {order.total.toFixed(2)}</p>
                <p className="text-gray-400">Endereço: {order.address}</p>
                <p className="text-gray-400">Pagamento: {order.paymentMethod}</p>
                <p className="text-gray-400">Tipo: {order.orderType === 'PICKUP' ? 'Retirada' : 'Entrega'}</p>
                {status === 'ACTIVE' && (
                  <div className="mt-4 space-x-2">
                    <button
                      onClick={() => onCompleteOrder(order.id)}
                      className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                    >
                      Finalizar Pedido
                    </button>
                    <button
                      onClick={() => onCancelOrder(order.id)}
                      className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
                    >
                      Cancelar Pedido
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}

      <button
        onClick={onBack}
        className="fixed bottom-4 right-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Voltar
      </button>
    </div>
  );
};

function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCheckout, setShowCheckout] = useState(false);
  const [orderType, setOrderType] = useState<OrderType>('PICKUP');
  const [orders, setOrders] = useState<Order[]>(loadOrdersFromLocalStorage());
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [orderCompleted, setOrderCompleted] = useState(false);
  const [minimized, setMinimized] = useState(false);

  // Efeito para salvar pedidos no localStorage
  useEffect(() => {
    saveOrdersToLocalStorage(orders);
  }, [orders]);

  // Efeito para tocar som de notificação ao receber um novo pedido
  useEffect(() => {
    if (orders.length > 0) {
      const audio = new Audio(notificationSound);
      audio.play();
    }
  }, [orders]);

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => 
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const removeFromCart = (itemId: number) => {
    setCart(prev => prev.filter(item => item.id !== itemId));
  };

  const updateQuantity = (itemId: number, quantity: number) => {
    if (quantity < 1) {
      removeFromCart(itemId);
      return;
    }
    setCart(prev => 
      prev.map(item => 
        item.id === itemId ? { ...item, quantity } : item
      )
    );
  };

 const handlePlaceOrder = async (address: string, paymentMethod: string, customerPhone?: string) => {
  const newOrder = {
    id: orders.length + 1,
    items: cart.map(item => ({ name: item.name, quantity: item.quantity })),
    total: cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
    address,
    paymentMethod,
    status: 'ACTIVE',
    createdAt: new Date(),
    orderType,
    customerPhone,
  };

  try {
    // Envia o pedido para o servidor do vendedor
    const response = await fetch('http://localhost:5000/pedidos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newOrder),
    });

    if (response.ok) {
      setOrders([...orders, newOrder]);
      setCart([]);
      setShowCheckout(false);
      setOrderCompleted(true);
    } else {
      alert('Erro ao enviar o pedido. Tente novamente.');
    }
  } catch (error) {
    console.error('Erro:', error);
    alert('Erro ao enviar o pedido. Tente novamente.');
  }
};

  const handleCancelOrder = (orderId: number) => {
    setOrders(prevOrders =>
      prevOrders.map(order =>
        order.id === orderId ? { ...order, status: 'CANCELLED' } : order
      )
    );
  };

  const handleCompleteOrder = (orderId: number) => {
    setOrders(prevOrders =>
      prevOrders.map(order =>
        order.id === orderId ? { ...order, status: 'COMPLETED' } : order
      )
    );
  };

  return (
    <div className="min-h-screen bg-gray-900">
      {isLoggedIn ? (
        <OrdersPage 
          orders={orders} 
          onBack={() => setIsLoggedIn(false)} 
          onCancelOrder={handleCancelOrder}
          onCompleteOrder={handleCompleteOrder}
        />
      ) : showCheckout ? (
        <CheckoutForm 
          onBack={() => setShowCheckout(false)}
          orderType={orderType}
          setOrderType={setOrderType}
          onPlaceOrder={handlePlaceOrder}
        />
      ) : (
        <>
          <header className="bg-black shadow-lg">
            <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
              <div className="flex items-center">
                <img src="/logo.png" alt="Logo" className="h-12 mr-4" />
                <h1 className="text-3xl font-bold text-white">Delicious Eats</h1>
              </div>
              <button
                onClick={() => setShowLogin(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
              >
                Área do Vendedor
              </button>
            </div>
          </header>

          <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <div>
                  <h2 className="text-2xl font-semibold mb-4 text-white">Food Menu</h2>
                  <MenuCarousel items={foodItems} onSelect={addToCart} itemsPerView={2} />
                </div>
                <div>
                  <h2 className="text-2xl font-semibold mb-4 text-white">Drinks Menu</h2>
                  <MenuCarousel items={drinkItems} onSelect={addToCart} itemsPerView={3} />
                </div>
              </div>

              <div className="lg:col-span-1">
                <Cart 
                  items={cart}
                  onUpdateQuantity={updateQuantity}
                  onRemove={removeFromCart}
                  onPlaceOrder={() => setShowCheckout(true)}
                />
              </div>
            </div>

            <ContactInfo />
          </main>
        </>
      )}

      {showLogin && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <LoginPage onLogin={handleLogin} />
        </div>
      )}

      {/* Modal de "Pedido Finalizado" */}
      {orderCompleted && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-black p-8 rounded-lg shadow-lg text-center">
            <h2 className="text-2xl font-bold text-white mb-4">Pedido Finalizado!</h2>
            <div className="space-x-2">
              <button
                onClick={() => setMinimized(!minimized)}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
              >
                {minimized ? 'Maximizar' : 'Minimizar'}
              </button>
              <button
                onClick={() => setOrderCompleted(false)}
                className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;