import express from 'express';
import cors from 'cors';
import { z } from 'zod';

const app = express();

app.use(cors());
app.use(express.json());

// Types
interface Order {
  id: string;
  items: OrderItem[];
  total: number;
  status: 'pending' | 'accepted' | 'preparing' | 'ready' | 'delivering' | 'delivered' | 'cancelled';
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  paymentMethod: 'card' | 'cash';
  createdAt: Date;
  updatedAt: Date;
}

interface OrderItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
}

// In-memory storage (replace with database in production)
let orders: Order[] = [];

// WhatsApp message templates
const getWhatsAppMessage = (order: Order, status: Order['status']) => {
  const messages = {
    accepted: `Olá ${order.customerName}! Seu pedido #${order.id} foi aceito e está sendo processado.`,
    preparing: `Seu pedido #${order.id} está sendo preparado com todo carinho!`,
    ready: `Boa notícia! Seu pedido #${order.id} está pronto e será enviado para entrega em breve.`,
    delivering: `Seu pedido #${order.id} saiu para entrega! Em breve chegará até você.`,
    delivered: `Pedido #${order.id} entregue! Agradecemos a preferência! 😊`,
    cancelled: `Lamentamos, mas seu pedido #${order.id} foi cancelado. Entre em contato conosco para mais informações.`
  };
  
  return messages[status] || '';
};

// Send WhatsApp message (mock implementation)
const sendWhatsAppMessage = async (phone: string, message: string) => {
  // In a real implementation, this would use the WhatsApp Business API
  console.log(`Sending WhatsApp message to ${phone}: ${message}`);
  return true;
};

// Validation schemas
const orderSchema = z.object({
  items: z.array(z.object({
    id: z.number(),
    name: z.string(),
    price: z.number(),
    quantity: z.number(),
  })),
  customerName: z.string(),
  customerPhone: z.string(),
  customerAddress: z.string(),
  paymentMethod: z.enum(['card', 'cash']),
});

// Routes
app.get('/api/orders', (req, res) => {
  res.json(orders);
});

app.post('/api/orders', (req, res) => {
  try {
    const validation = orderSchema.parse(req.body);
    
    const newOrder: Order = {
      id: Date.now().toString(),
      ...validation,
      status: 'pending',
      total: validation.items.reduce((sum, item) => sum + (item.price * item.quantity), 0),
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    orders.push(newOrder);
    res.status(201).json(newOrder);
  } catch (error) {
    res.status(400).json({ error: 'Invalid order data' });
  }
});

app.patch('/api/orders/:id/status', async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!['pending', 'accepted', 'preparing', 'ready', 'delivering', 'delivered', 'cancelled'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  const order = orders.find(o => o.id === id);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  order.status = status as Order['status'];
  order.updatedAt = new Date();

  // Send WhatsApp notification if status changed
  if (status !== 'pending') {
    const message = getWhatsAppMessage(order, status as Order['status']);
    if (message) {
      await sendWhatsAppMessage(order.customerPhone, message);
    }
  }

  res.json(order);
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Vendor server running on port ${PORT}`);
});