export interface MenuItem {
  id: number;
  name: string;
  price: number;
  image: string;
}

export interface CartItem extends MenuItem {
  quantity: number;
}

export type OrderType = 'PICKUP' | 'DELIVERY';
export type PaymentMethod = 'CASH' | 'PIX' | 'CARD';

export interface DeliveryInfo {
  type: OrderType;
  address?: string;
  paymentMethod: PaymentMethod;
}